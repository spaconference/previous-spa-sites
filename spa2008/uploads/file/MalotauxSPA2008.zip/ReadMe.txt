Files in this zip:

SPA2008forCD.pdf - Tutorial presentation slides ppt>pdf 1 slide per screen
SPA2008-2A4.pdf  - Tutorial handout 2 slides per page A4
Booklet2.pdf     - Booklet "How Quality is Assured by Evolutionary Methods"
TimeLine.pdf     - Booklet "TimeLine - Getting and Keeping Control over your Project"
EvoRisk.pdf      - Booklet "Controlling Project Risk by Design"
ETA.zip          - Evo Task Administrator (ETA) tool (MSAccess2003). Includes ReadMe file.

Read booklets in the order:
1. Booklet2.pdf
2. TimeLine.pdf
3. EvoRisk.pdf

The ETA tool works with MSAccess2003.
Background for the tool is in the ReadMe file (contained in ETA.zip) and in the booklets, mainly Booklet2.pdf.

The handout is to be printed two-sided on 17 sheets of A4, containing:
- 2 starting pages
- 30 slide pages
- exercise sheet
Although the handout is in color, it can be printed on a Black/White printer.